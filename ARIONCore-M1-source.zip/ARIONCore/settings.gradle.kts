rootProject.name = "ARIONCore"
